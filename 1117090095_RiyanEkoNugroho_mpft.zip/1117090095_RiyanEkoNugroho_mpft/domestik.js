$$(document).on('page:init', '.page[data-name="domestik"]', function () {
	$$('#domestik-msg').html('');
	$$("#domestik-list-btn").on('click', function() {
		app.request.get(serverEndPoint.url + 'transferDomestic', {}, function(success){
			dataTransfer = success;
			app.views.main.router.navigate('/domestik-list/', {reloadCurrent: true, transition: 'f7-circle'});
		}, function (error) {
			alert(error);
		}, 'json');

	});
	
	$$("#domestik-submit-btn").on('click', function() {
		var form = app.form.convertToData('#domestik-form');
		if (form.accountNoDestination == null || form.accountNoDestination.trim() == '') {
			app.dialog.alert('Empty Destination Account No', chodoApp.name, function() {});
			return;
		}
		
		if (form.nominal == null || form.nominal.trim() == '' || form.nominal.trim() == '0') {
			app.dialog.alert('Empty Amount', chodoApp.name, function() {});
			return;
		}
		
		var nominal = form.nominal;
		delete form.nominal;
		
		form.nominal = parseInt(nominal);
		if (form.nominal == 'undefined' || form.nominal == undefined) {
			app.dialog.alert('Invalid Amount', chodoApp.name, function() {});
			return;
		}

        form.bankCode;
        form.accountNoOrigin = user.accountNo;
        form.referalCode;
		form.description;

		app.request({
            method: 'POST',
            url: serverEndPoint.url + 'transferDomestic',
            contentType: 'application/json',
            data: form,
            async: false,
            success: function(data) {
                var domestik = JSON.parse(data);
                //app.views.main.router.navigate('/domestik/', {reloadCurrent: true, transition: 'f7-circle'});
                $$('#domestik-msg').html(domestik.responseMsg);
            },
            error: function(err) {
            	app.dialog.alert(err, chodoApp.name, function() {});
            	console.log(err);
                return;
            }
        });
		
	});
	
	$$(".chodosoft-footer").html('<div class="chodosoft-center">' +
			'<div class="chodosoft-font-9">' + chodoApp.footer.name + '</div>' +
			'<br />' +
		'</div>');
});
