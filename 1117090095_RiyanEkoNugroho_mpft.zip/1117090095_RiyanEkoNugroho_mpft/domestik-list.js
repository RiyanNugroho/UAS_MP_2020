$$(document).on('page:init', '.page[data-name="domestik-list"]', function () {
	var view = {
			html : ''
	};
	console.log(dataDomestik);
	if (dataDomestik != null && dataDomestik.length > 0) {
		for (var i = 0; i < dataDomestik.length; i++) {
			view.html += '<div class="col-100 card chodosoft-color-bg-blue" id="' + dataDomestik[i].id + '-btn" >' + 
					'<div class="card-content card-content-padding" >' +
						'<div class="row">' +
							'<div class="col-50">Reference No: <strong>' + dataDomestik[i].code + '</strong></div>' +
							'<div class="col-50 chodosoft-right">' + dataDomestik[i].currency + ' <strong>' + dataDomestik[i].totalAmount + '</strong></div>' +					
						'</div>' +
						'<div class="row">' +
							'<div class="col-50">Destination Name: ' + dataDomestik[i].user.name + '<br />' +
								'Account No: ' +dataDomestik[i].user.accountNo +
							'</div>' +
							'<div class="col-50 chodosoft-right">' + dataDomestik[i].cdt + '</div>' + 
						'</div>' +
						'<div class="row">' +
							'<div class="col-90 chodosoft-center">' + 
								'<h3>Note</h3>' +
								dataDomestik[i].description + 
                            '</div>' +
						'</div>' +
						'<div class="row">' +
							'<div class=" chodosoft-center">' + 
								'<a class="col button button-fill color-red text-color-white">Delete</a>' +
							'</div>' +
						'</div>' +
					'</div>' +
				'</div>';
		}
	}
	
	$$('#list-domestik').html(view.html);
	$$(".chodosoft-footer").html('<div class="chodosoft-center">' +
			'<div class="chodosoft-font-9">' + chodoApp.footer.name + '</div>' +
			'<br />' +
		'</div>');
});
